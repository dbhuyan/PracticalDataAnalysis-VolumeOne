var express = require('express')
var exec = require('child_process').exec
var app = express()

const dataPath = "../data/"
const elasticHost = "http://localhost:9200/"
var restrictedIndex = ['allgrcissues', 'allactionplans']

app.use('*', (req, res) => {
	var oldORnew = req.get('oldORnew')
	var indexName = req.get('indexName')
	var fileName = req.get('fileName')
	var count = req.get('count')
	var uploadDestination = req.get('uploadDestination')
	var fileMimeType = req.get('fileMimeType')

	// console.log(oldORnew, indexName, fileName, count, fileMimeType, uploadDestination)

	if ((indexName != '') && (uploadDestination == 'elasticsearch') && (!restrictedIndex.includes(indexName))) {
		
		if ((count == 0) & (oldORnew == 'New')) {
			// Delete index if it exists
			let myCommand = "curl -XDELETE " + elasticHost + indexName + " --silent"
			exec(myCommand)
		}

		if (fileMimeType == 'text/csv') {
			let myCommand = "./abc import --src_type=csv --src_uri=\"" + dataPath + fileName + ".bin\" --typename=dataset " + elasticHost + indexName + " && rm -f " + dataPath + fileName + "*"
			exec(myCommand)
		} else {
			// Assuming it is an Excel file, try converting it to CSV and then upload it to Elastic
			let commandA = "ssconvert "+ dataPath + fileName + ".bin " + dataPath + fileName + ".csv"
			let commandB = "./abc import --src_type=csv --src_uri=\"" + dataPath + fileName + ".csv\" --typename=dataset " + elasticHost + indexName
			let commandC = "rm -f " + dataPath + fileName + "*"
			let finalCommand = commandA + " && " + commandB + " && " + commandC
			exec(finalCommand)
		}
	} else {
		// Delete the uploaded files
		// console.log("Index exception")
		let myCommand = "rm -f " + dataPath + fileName + "*"
		exec(myCommand)
	}
	
	res.status(200).send("Upload in progress ...");
});

app.listen(3001, 'localhost');
