import React from 'react'
import './App.css'
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Typography from '@material-ui/core/Typography';
import Toolbar from '@material-ui/core/Toolbar';
import Home from '@material-ui/icons/Home';

const Uppy = require('@uppy/core')
const Tus = require('@uppy/tus')
const Dashboard = require('@uppy/dashboard')
const Form = require('@uppy/form')

// File server is the tusd server.
// Once a file is uploaded to the file server, the uploadServer does the uploading to Elasticsearch.
const uploadServer = "http://localhost:3002/elasticdatauploader/upload/"
const fileServer = "http://localhost:5001/files/"
const homepage = "/"

const uppy = Uppy({
  debug: false,
  restrictions: {
  	allowedFileTypes: ['.csv', '.xlsx', '.xls']
  }
})

uppy.use(Dashboard, {
  inline: true,
  target: '#drag-drop-area',
  plugins: ['Tus'],
  trigger: '#uppy-select-files',
  showProgressDetails: true,
  proudlyDisplayPoweredByUppy: false,
  note: 'Upload .csv, .xlsx or .xls file types only. No restrictions on the number of files or file size.',
  hideProgressAfterFinish: false,
  showLinkToFileUploadResult: false,
  locale: {
  	strings: { cancel: 'Go Back' }
  }
})

uppy.use(Tus, {endpoint: fileServer})

uppy.use(Form, {
  target: '#metadata-form',
  getMetaFromForm: true,
  addResultToForm: true,
  resultName: 'uppyResult',
  submitOnSuccess: false
})

uppy.on('complete', (result) => {
  let count = 0
  for (var item in result.successful) {
    let oldORnew = result.successful[item].meta.oldORnew
    let indexName = result.successful[item].meta.indexName
    let fileName = result.successful[item].tus.uploadUrl.split('/').pop()
    let uploadDestination = result.successful[item].meta.uploadDestination
    let fileMimeType = result.successful[item].meta.type

    // Call API to load data to Elastic
    
    fetch(uploadServer, {
          method: 'GET',
          headers: {
              'oldORnew': oldORnew,
              'indexName': indexName,
              'fileName': fileName,
              'count': count,
              'uploadDestination': uploadDestination,
              'fileMimeType': fileMimeType
          }
        })
    
    count = count + 1   
  }
})


const styles = {
  root: {
    flexGrow: 1,
  },
  grow: {
    flexGrow: 1,
  },
  appBar: {
  	top: 'auto',
  	bottom: 0,
  },
};

class App extends React.Component {

  render() {
    const { classes } = this.props;

    return (
      <div className={classes.root}>
        <AppBar position="fixed">
	        <Toolbar>
	            <Typography variant="h5" color="inherit" className={classes.grow}>
	              Upload Data to Elasticsearch
	            </Typography>
	        </Toolbar>
        </AppBar>
        <AppBar position="fixed" color="primary" className={classes.appBar}>
			<Toolbar>
        <Home style={{margin: 10}} />
				<a href={homepage}>
	            <Typography variant="h6" color="inherit" className={classes.grow}>
	              Go Back To Homepage
	            </Typography>
	            </a>
	        </Toolbar>
      	</AppBar>
      </div>
    );
  }
}

App.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(App);
