const proxy = require('http-proxy-middleware');

module.exports = function(app) {
  app.use(proxy('/elasticdatamaintenance/elastic', { target: 'http://localhost:9200/' , pathRewrite: {'^/elasticdatamaintenance/elastic' : '/'}}));
};
