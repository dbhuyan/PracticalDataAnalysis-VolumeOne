import React from 'react';
import './App.css';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Typography from '@material-ui/core/Typography';
import Toolbar from '@material-ui/core/Toolbar';
import Home from '@material-ui/icons/Home';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Button from '@material-ui/core/Button';

const homepage = "/";
const elasticPath = "/elasticdatamaintenance/elastic";
const restricrtedList = ['.kibana', 'dhirajbhuyan', 'womensclothingreviews'];

const CustomTableCell = withStyles(theme => ({
  head: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
    fontSize: 14,
    fontWeight: 'bold',
  },
  body: {
    fontSize: 14,
  },
}))(TableCell);

const styles = theme => ({
  root: {
    flexGrow: 1,
  },
  table: {
    minWidth: 700,
    align: 'center',
  },
  row: {
    '&:nth-of-type(odd)': {
      backgroundColor: theme.palette.background.default,
    },
  },
  grow: {
    flexGrow: 1,
    color: '#ffffff',
  },
  appBar: {
    top: 'auto',
    bottom: 0,
  },
  button: {
    color: theme.palette.common.black,
  }
});

class App extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      data: ''
    };
  }

  async componentWillMount () {
    var url = elasticPath + '/_cat/indices?h=i,dc,ss,creation.date.string';
    try {
      let response = await fetch(url);
      let data = await response.text();
      this.setState({data: data});
    } catch (error) {
      console.error(error);
    }
  }

  render() {
    const { classes } = this.props;
    const rows = this.state.data.split(/\n/);

    async function DeleteIndex(index) {
      const url = elasticPath + '/' + index;
      let response = await fetch(url, {
        method: 'delete'
      });
      await response.text();
      window.location.reload();
      return;
    }

    function refreshData() {
      window.location.reload();
      return;
    }
    
    function renderRows(row) {
      const cells = row.split(/\s+/);
      const date = new Date(cells[3]);
      if (row === '') {
        return;
      } else {
        if (restricrtedList.includes(cells[0])) {
          return(
                  <TableRow className={classes.row} key={cells[0]}>
                    <CustomTableCell>{cells[0]}</CustomTableCell>
                    <CustomTableCell>{cells[1]}</CustomTableCell>
                    <CustomTableCell>{cells[2]}</CustomTableCell>
                    <CustomTableCell>{date.toLocaleString()}</CustomTableCell>
                    <CustomTableCell></CustomTableCell>
                  </TableRow>
          );
        } else {
                return(
                  <TableRow className={classes.row} key={cells[0]}>
                    <CustomTableCell>{cells[0]}</CustomTableCell>
                    <CustomTableCell>{cells[1]}</CustomTableCell>
                    <CustomTableCell>{cells[2]}</CustomTableCell>
                    <CustomTableCell>{date.toLocaleString()}</CustomTableCell>
                    <CustomTableCell>
                      <Button variant="outlined" color="secondary" onClick={() => DeleteIndex(cells[0])} >
                          Delete
                      </Button>
                    </CustomTableCell>
                  </TableRow>
                );

          }
      }
    };

    const tableRows = rows.map(row => renderRows(row));

    return (
      <div className={classes.root}>
        <AppBar position="fixed">
          <Toolbar>
              <Typography variant="h5" color="inherit" className={classes.grow}>
                Elasticsearch Data Maintenance
              </Typography>
              <Button variant="contained" className={classes.button} onClick={() => refreshData()}>Refresh Data</Button>
          </Toolbar>
        </AppBar>
        <br/><br/><br/>
        <div style={{textAlign: 'center', padding: 40}} >
                The current list of Elasticsearch index is shown below. <br/> If you delete an index, you will permanently lose the data in that index.
        </div>
 
          <Table className={classes.table}>
            <TableHead>
              <TableRow>
                <CustomTableCell>Index Name</CustomTableCell>
                <CustomTableCell>Number of Data Rows</CustomTableCell>
                <CustomTableCell>Index Size</CustomTableCell>
                <CustomTableCell>Date Created</CustomTableCell>
                <CustomTableCell>Action</CustomTableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {tableRows}
            </TableBody>
          </Table>

        <AppBar position="fixed" color="primary" className={classes.appBar}>
        <Toolbar>
              <Home style={{margin: 10}} />
              <a href={homepage}>
              <Typography variant="h6" className={classes.grow}>
                Go Back To Homepage
              </Typography>
              </a>
          </Toolbar>
        </AppBar>
      </div>
    );
  }
}

App.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(App);