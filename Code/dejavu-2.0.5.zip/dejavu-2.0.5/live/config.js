const BRANCH = 'dev';
var config = {
	"hostname": "scalr.api.appbase.io",
	"appname": "housing-demo",
	"username": "YnCgVwozV",
	"password": "e9ec5cb0-58d8-4bb0-badc-acaf726661f1",
	"email":"support@appbase.io",
	"url":"https://YnCgVwozV:e9ec5cb0-58d8-4bb0-badc-acaf726661f1@scalr.api.appbase.io"
};
