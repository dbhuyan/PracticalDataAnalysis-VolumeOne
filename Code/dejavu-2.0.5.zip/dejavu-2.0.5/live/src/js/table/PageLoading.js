var React = require('react');

class pageLoading extends React.Component {
	render() {
		return (<div className="pageLoading">
					<div className="loadingBar"></div>
					<div className="vertical1">
					</div>  
				</div>);
	}
}

module.exports = pageLoading;
