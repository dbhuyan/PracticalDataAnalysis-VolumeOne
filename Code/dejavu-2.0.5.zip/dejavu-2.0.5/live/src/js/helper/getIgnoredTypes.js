const ignoredTypes = [
	'~percolator',
	'~logs',
	'.percolator',
	'.logs'
];

export default ignoredTypes;
