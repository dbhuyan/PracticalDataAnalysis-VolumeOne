---
name: General Issue
about: Bugs, enhancements and feature requests

---

#### Tell us where you are using Dejavu (Hosted web app, Chrome extension, Docker Image, Within appbase.io)


#### What is the version of Dejavu that you are using?


#### Describe the issue that you are seeing, or the feature request :-), include any screenshots as necessary.


##### If your issue deals with accessing Elasticsearch cluster, share the necessary steps to replicate the behavior (the configuration.yml settings, where your ES cluster is hosted, any relevant logs).

##### If your issue deals with a UI issue, share with us a screenshot of the failing network request or the browser console log showing the error.
